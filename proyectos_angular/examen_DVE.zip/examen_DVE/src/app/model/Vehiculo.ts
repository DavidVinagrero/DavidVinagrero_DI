class Vehiculo {
  constructor(
    public nombre: string,
    public marca: string,
    public cv: number,
    public tipo: string,
    public imagen: string
  ) {}
}
