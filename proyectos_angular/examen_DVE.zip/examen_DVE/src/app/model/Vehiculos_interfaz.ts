export interface VehiculosInterfaz {
  nombre: string;
  marca: string;
  cv: number;
  tipo: string;
  imagen: string;
}
